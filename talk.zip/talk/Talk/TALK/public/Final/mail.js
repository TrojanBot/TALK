// const firebaseConfig = {
// apiKey: "AIzaSyD1wUdc47FobiMKcVmRb4doo6HAtE4qBBU",
// authDomain: "talk-7d6f0.firebaseapp.com",
// databaseURL: "https://talk-7d6f0-default-rtdb.firebaseio.com",
// projectId: "talk-7d6f0",
//storageBucket: "talk-7d6f0.appspot.com",
//messagingSenderId: "1060969580165",
//appId: "1:1060969580165:web:1233f7eecd39200c7dcbec",
//measurementId: "G-Y3SJMLCCSQ"
//};
// firebase.initializeApp(firebaseConfig);

const firebaseConfig = {
    apiKey: "AIzaSyD1wUdc47FobiMKcVmRb4doo6HAtE4qBBU",
    authDomain: "talk-7d6f0.firebaseapp.com",
    databaseURL: "https://talk-7d6f0-default-rtdb.firebaseio.com",
    projectId: "talk-7d6f0",
    storageBucket: "talk-7d6f0.appspot.com",
    messagingSenderId: "1060969580165",
    appId: "1:1060969580165:web:1233f7eecd39200c7dcbec",
    measurementId: "G-Y3SJMLCCSQ"
  };
  
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

var database = firebase.database();
var firebaseOrdersCollection = database.ref().child('Interview_details');

const KEY_SIZE = 15;

var rand = random(KEY_SIZE);

document.getElementById("schedule-form").addEventListener("submit", function(event) {
    event.preventDefault();
    document.getElementById("schedule-submit-btn").innerHTML = `sending...`;
    sendmail();
});


function sendmail() {

    rand = random(KEY_SIZE);
    submitdetails();
}

function random(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return (result);
}

function submitdetails() {
    var details = {
        Interviewer_name: $('#P1name').val(),
        Interviewee_name: $('#P2name').val(),
        Interviewee_email: $("#P2email").val(),
        Interviewer_email: $("#P1email").val(),
        Date_: $("#date-time").val(),
        Key: rand,
    };

    firebaseOrdersCollection.child(rand).set(details);

    sendtointerviewee();
    sendtointerviewer();
    sendtotalkmeetings();
};


function sendtointerviewee() {
    Email.send({

        Host: "smtp.gmail.com",
        Username: "talkmeetings73@gmail.com",
        Password: "talkmeetings@18",
        To: $("#P2email").val(),
        From: "talkmeetings73@gmail.com",
        Subject: "Interview Confirmation",
        Body: "Hey " + $("#P2name").val() + " ,\r\r" + "Your interview has been scheduled on " + $("#date-time").val().split("T")[0] + " at " + $("#date-time").val().split("T")[1] + ". Join the room with the key - " + rand + "E" + "\n\n. Wish you the best.",
    })
}

function sendtointerviewer() {
    Email.send({

        Host: "smtp.gmail.com",
        Username: "talkmeetings73@gmail.com",
        Password: "talkmeetings@18",
        To: $("#P1email").val(),
        From: "talkmeeings@",
        Subject: "Interview Confirmation",
        Body: "You interview with " + $("#P2name").val() + " has been scheduled on " + $("#date-time").val().split("T")[0] + " at " + $("#date-time").val().split("T")[1] + ". Join the room with the key - " + rand + "R",
    })
}


function sendtotalkvirtual() {
    Email.send({

        Host: "smtp.gmail.com",
        Username: "talkmeetings73@gmail.com",
        Password: "takmeetings@18",
        To: "talkmeetings73@gmail.com",
        From: "talkmeetings73@gmail.com",
        Subject: "Launch the lab",
        Body: $("#date-time").val().split(" ")[0] + " at " + $("#date-time").val().split(" ")[1] + " " + $("#date-time").val().split(" ")[2] + ". Please launch the lab and ensure it is functional .",
    }).then(
        e => {
            document.getElementById("schedule-submit-btn").innerHTML = `
            <audio autoplay>
                <source src="./assets/insight.mp3#t=00:00:01" type="audio/ogg">
            </audio>
            SENT
            <svg class="tick-svg" xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24"><path d="M20.285 2l-11.285 11.567-5.286-5.011-3.714 3.716 9 8.728 15-15.285z"/></svg>`;
            setTimeout(function() { document.getElementById("schedule-submit-btn").innerHTML = `SEND`;
                document.getElementById("schedule-form").reset(); }, 3000);
        }
    );
}


//---- contact us -------

document.getElementById("contact-form").addEventListener("submit", function(event) {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;

    event.preventDefault();

    document.getElementById("contact-submit-btn").innerHTML = `sending...`;

    Email.send({
        Host: "smtp.gmail.com",
        Username: "talkmeetings73@gmail.com",
        Password: "talkmeetings@18",
        To: "talkmeetings73@gmail.com",
        From: $("#email").val(),
        Subject: $("#name").val() + "'s query",
        Body: $("#message").val(),
    }).then(
        e => {
            document.getElementById("contact-submit-btn").innerHTML = `
            <audio autoplay>
                <source src="./assets/insight.mp3#t=00:00:01" type="audio/ogg">
            </audio>
            SENT
            <svg class="tick-svg" xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24"><path d="M20.285 2l-11.285 11.567-5.286-5.011-3.714 3.716 9 8.728 15-15.285z"/></svg>`;
            setTimeout(function() { document.getElementById("contact-submit-btn").innerHTML = `SEND`;
                document.getElementById("contact-form").reset(); }, 3000);
        }
    );

});