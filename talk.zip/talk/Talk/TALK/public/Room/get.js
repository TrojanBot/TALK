const firebaseConfig = {
    apiKey: "AIzaSyD1wUdc47FobiMKcVmRb4doo6HAtE4qBBU",
    authDomain: "talk-7d6f0.firebaseapp.com",
    projectId: "talk-7d6f0",
    storageBucket: "talk-7d6f0.appspot.com",
    messagingSenderId: "1060969580165",
    appId: "1:1060969580165:web:1233f7eecd39200c7dcbec",
    measurementId: "G-Y3SJMLCCSQ"
  };

firebase.initializeApp(firebaseConfig);
var database = firebase.database();
var fire = database.ref().child("Lab_details");
var val;

function getlab(roomId) {
    val = roomId;
    fire.on("value", gotData);
    function gotData(data) {
        data = data.val();
        let keys = Object.keys(data);
        for (var i = 0; i < keys.length; i++) {
            if (keys[i] == roomId) {
                document.getElementById("lab").setAttribute("src", keys[i].two);
            }
        }
    }
}
